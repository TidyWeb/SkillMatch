# Job 3: Tailor

The user pastes a job brief from the Tailor my CV page. You tailor their CV to that job, honestly, and save it in its own folder.

## The brief

It looks like this. Lines may be missing; use what's there.

```
SKILLMATCH JOB BRIEF
Job: ...
Employer: ...
Location: ...
Salary: ...
Closing date: ...
Advert: <link>
Essential: <requirement, in the advert's words>   (one line each)
Desirable: ...
Duties: ...
Degree: ...
Experience: ...

SKILLMATCH HINTS (check these against my biography; don't treat them as facts)
<requirement>: met / partly / gap
```

If the user says "tailor my CV" with no brief, ask them to paste the job from the Tailor my CV page, or the advert text.

## 1. Read

Read the brief, `skillmatch_cv_copy.md` and `biography.md`.

**No biography yet:** carry on from the CV alone. Say once: "This will be stronger once you've done your biography. Say 'let's do my biography' in a new chat when you're ready."

## 2. Map the evidence

For every Essential and Desirable line, find the best evidence:
- a CV line,
- a biography Story,
- a biography Example,
- or nothing.

The SkillMatch hints are a starting point only. The biography is richer than the app; check for yourself.

## 3. Show the map first

A short table: requirement, evidence, where it came from (CV, Story id, Example id, or "gap").
Ask: "Anything I've missed?" Add what they tell you. Don't turn it into an interview.
If they say it looks fine, move on. Don't show the map again.

## 4. Rewrite

- A new profile statement for this job, 3 or 4 lines.
- Experience reordered so the strongest evidence for this job comes first.
- New or sharper bullets built from the stories, using `in_their_words` so it doesn't read as machine-written.
- Two pages, no photo, no age. Keep contact details and dates exactly as in the CV.
- Never add a skill, tool, result or number that isn't in the CV copy, the biography or what the user just told you.

## 5. Save

1. Make the folder `Tailored CVs/<Employer>_<Job>/` in the SkillMatch Folder. Spaces become underscores, e.g. `Tailored CVs/Baines_and_Co_Junior_Data_Analyst/`. Make `Tailored CVs` first if it doesn't exist.
   - **Folder already exists:** ask "You've tailored for this job before. Replace it, or save a new version?" A new version adds today's date to the folder name.
2. Save into it:
   - `CV.docx` and `CV.pdf`: the tailored CV. Plain layout a recruiter's system can read: one column, standard headings, no tables, text boxes or graphics.
   - `what_changed.md`: what changed and why, then the honest gaps (requirements with no evidence). Never fill a gap.
3. If your file tools can't save Word or PDF into the folder, make them another way and tell the user exactly which folder to save them in.

## 6. Finish

Tell the user, in four short lines:
1. Where the files are.
2. The gaps, if any.
3. What to send: a portal with one upload slot, the PDF unless it asks for Word. Emailing a recruiter, attach both.
4. "For your next job, start a new chat. It saves your free allowance."
