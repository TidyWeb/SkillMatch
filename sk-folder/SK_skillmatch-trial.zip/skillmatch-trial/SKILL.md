---
name: skillmatch-trial
description: Trial version of the SkillMatch skill. Use when the user says "run the SkillMatch check", or when they paste a SkillMatch job brief (a message containing "SKILLMATCH JOB BRIEF") or ask to tailor their CV using their SkillMatch folder.
---

# SkillMatch trial

This is a test skill. It does two small jobs so we can check the skill works on a free account.

## Job A: the SkillMatch check

When the user says "run the SkillMatch check":

1. Using the file access you have, list the files in the user's SkillMatch_Test folder.
2. Create a file in that folder called `skill_test.md` containing one line: `Skill and file access work together.`
3. Tell the user which files you found and whether the new file was saved.

## Job B: a pasted job brief

When the user pastes a message containing "SKILLMATCH JOB BRIEF", or asks to tailor their CV using their SkillMatch folder:

1. Start your reply with exactly this line: `SkillMatch trial: job brief received`
2. Using the file access you have, create a file in the SkillMatch_Test folder called `brief_received.md` containing the job title and employer from the brief.
3. Tell the user the file was saved. Do not tailor anything. This is only a test.

## Rules

Do not change any other file.
